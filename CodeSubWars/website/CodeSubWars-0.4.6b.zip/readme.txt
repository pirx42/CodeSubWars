CodeSubWars 0.4.6 (587) beta

A physics based three dimensional programming game.


Content of archive
------------------
The archive contains the following file structure (only important files/folders are 
described):
root
  +-CodeSubWars.exe   The main executable.
  +-changes.txt       The detailed list of changes.
  +-preferences.cfg   The current stored preferences.
  +-readme.txt        This file.
  +-doc
    +-Manual.pdf      The common description of the codesubwars environment.
    +-html
      +-index.html    The main entry point for the html based reference documentation.
  +-pylib             The python library main folder containing useful common python 
                      code for implementing submarines.
  +-submarines        This folder contains available subarmines that can be loaded on 
                      start of a battle.
  

Installation
------------
* extract the archive into a folder e.g. c:\program files\CodeSubWars 
* it is recommend to get and install python 2.5 (available at http://www.python.org) 
  but not necessary when only using python build in functions
* start the application e.g. located in c:\program files\CodeSubWars\CodeSubWars.exe


System requirements
-------------------
* Windows 2000/XP
* 128Mb free memory
* Pentium 4 (or compatible) or higher, SSE
* Graphics card that supports OpenGL 1.2 or higher (in graphic mode)


Features
--------
* Easy to implement new submarines using python
* Easy to set up new behavior by using predefined commands
* Easy to implement completely new commands using python
* Three dimensional environment
* Physics based environment


Known bugs/issues
-----------------
* Restarting a new battle that contains submarines which uses graphical user interface 
  environment (tkinter) works not properly.
* Replaying long battle records takes very long loading time.
* When a battle is stopped, not all memory is freed.
* Cause of beeing able to create references to itself (e.g. by holding self in member 
  variable of submarine) circular references could be created. This leads to memory 
  leaks.


History
-------
* Version 0.4.6b (2007/01/02)
  - new example submarine
  - some bugs removed

* Version 0.4.5b (2006/09/24)
  - new weapons: magnetic mine, passive sonar guided torpedo
  - example submarines now uses faster rotation and move commands
  - threads can now be used within python
  - several major and minor bugs removed

* Version 0.4.0b (2006/01/21)
  - commands can be implemented in python
  - new example submarine 
  - reference documentation improved
  - several minor bugs removed

* Version 0.3.1b (2005/11/26)
  - serious bug regarding to collision detection fixed
  - pylib subfolder introduced that contains useful common python code

* Version 0.3.0b (2005/09/02)
  - new equipment added: passive sonar
  - visualization improved
  - new example submarines
  - performance improved
  - some bugs were fixed

* Version 0.2.0b (2005/07/29)
  - new equipment added: map 
  - new silent mode added which has no graphical output
  - replaying of battles is now possible
  - weapon batteries can now be recharged on weapon supplies
  - new basic commands are available: repeat, push, pop
  - performance improved
  - some bugs were fixed

* Version 0.1.0b (2005/05/22)
  - Initial release

See changes.txt for more detailed description.


Copyright/License
-----------------
CodeSubWars is Copyright (c) 2005-2007 Andreas Rose

Permission is hereby granted by the author to copy and distribute this archiv "as is" 
for any purpose, without fee. Permission is hereby granted by the author to use the 
content of this archiv for any purpose, without fee.
The author claims no responsibility for any damage or otherwise undesired outcome 
that CodeSubWars may cause, and offer no additional assistance on using the resource. 
The author does not guarantee that CodeSubWars will work as expected. The user employs 
CodeSubWars at his or her own risk.



For bug reports contact bug@codesubwars.org.
Watch out http://www.codesubwars.org for upcoming releases.

If you have any suggestion please do not hesitate to contact pirx@codesubwars.org.
